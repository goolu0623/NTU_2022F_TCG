Compile:
% make

Usage: ./verifier -i [executable_program] -d [input_data]
 -i [your program]
 -d [test case]

Usage example:
 % ./verifier -i ./a.out -d input.in
